﻿namespace midterm_section2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.btn1 = new System.Windows.Forms.Button();
            this.btn2 = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.btn3 = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.btn4 = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.txt1 = new System.Windows.Forms.TextBox();
            this.txt3 = new System.Windows.Forms.TextBox();
            this.txt5 = new System.Windows.Forms.TextBox();
            this.txt7 = new System.Windows.Forms.TextBox();
            this.txt8 = new System.Windows.Forms.TextBox();
            this.txt6 = new System.Windows.Forms.TextBox();
            this.txt4 = new System.Windows.Forms.TextBox();
            this.txt2 = new System.Windows.Forms.TextBox();
            this.btn5 = new System.Windows.Forms.Button();
            this.btn6 = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(72, 76);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(85, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "Metric sq cm ";
            // 
            // btn1
            // 
            this.btn1.Location = new System.Drawing.Point(238, 94);
            this.btn1.Name = "btn1";
            this.btn1.Size = new System.Drawing.Size(111, 23);
            this.btn1.TabIndex = 1;
            this.btn1.Text = "&1st conversion";
            this.btn1.UseVisualStyleBackColor = true;
            this.btn1.Click += new System.EventHandler(this.btn1_Click);
            // 
            // btn2
            // 
            this.btn2.Location = new System.Drawing.Point(238, 158);
            this.btn2.Name = "btn2";
            this.btn2.Size = new System.Drawing.Size(111, 23);
            this.btn2.TabIndex = 3;
            this.btn2.Text = "&2nd conversion  ";
            this.btn2.UseVisualStyleBackColor = true;
            this.btn2.Click += new System.EventHandler(this.btn2_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(72, 138);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(75, 16);
            this.label2.TabIndex = 2;
            this.label2.Text = "Metric sq m";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // btn3
            // 
            this.btn3.Location = new System.Drawing.Point(238, 220);
            this.btn3.Name = "btn3";
            this.btn3.Size = new System.Drawing.Size(111, 23);
            this.btn3.TabIndex = 5;
            this.btn3.Text = "&3th conversion  ";
            this.btn3.UseVisualStyleBackColor = true;
            this.btn3.Click += new System.EventHandler(this.btn3_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(72, 202);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(86, 16);
            this.label3.TabIndex = 4;
            this.label3.Text = "Metric hectar ";
            // 
            // btn4
            // 
            this.btn4.Location = new System.Drawing.Point(238, 275);
            this.btn4.Name = "btn4";
            this.btn4.Size = new System.Drawing.Size(111, 23);
            this.btn4.TabIndex = 7;
            this.btn4.Text = "&4th conversion  ";
            this.btn4.UseVisualStyleBackColor = true;
            this.btn4.Click += new System.EventHandler(this.btn4_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(72, 263);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(85, 16);
            this.label4.TabIndex = 6;
            this.label4.Text = "Metric sq km ";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(404, 263);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(75, 16);
            this.label5.TabIndex = 11;
            this.label5.Text = "US sq mile ";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(404, 202);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(63, 16);
            this.label6.TabIndex = 10;
            this.label6.Text = "US acres";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(404, 138);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(65, 16);
            this.label7.TabIndex = 9;
            this.label7.Text = "US sq yd ";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(404, 76);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(60, 16);
            this.label8.TabIndex = 8;
            this.label8.Text = "US sq in ";
            // 
            // txt1
            // 
            this.txt1.Location = new System.Drawing.Point(75, 95);
            this.txt1.Name = "txt1";
            this.txt1.Size = new System.Drawing.Size(100, 22);
            this.txt1.TabIndex = 0;
            this.txt1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txt3
            // 
            this.txt3.Location = new System.Drawing.Point(75, 159);
            this.txt3.Name = "txt3";
            this.txt3.Size = new System.Drawing.Size(100, 22);
            this.txt3.TabIndex = 3;
            this.txt3.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txt5
            // 
            this.txt5.Location = new System.Drawing.Point(75, 221);
            this.txt5.Name = "txt5";
            this.txt5.Size = new System.Drawing.Size(100, 22);
            this.txt5.TabIndex = 4;
            this.txt5.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txt7
            // 
            this.txt7.Location = new System.Drawing.Point(75, 282);
            this.txt7.Name = "txt7";
            this.txt7.Size = new System.Drawing.Size(100, 22);
            this.txt7.TabIndex = 5;
            this.txt7.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txt8
            // 
            this.txt8.Location = new System.Drawing.Point(407, 282);
            this.txt8.Name = "txt8";
            this.txt8.Size = new System.Drawing.Size(100, 22);
            this.txt8.TabIndex = 19;
            this.txt8.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txt6
            // 
            this.txt6.Location = new System.Drawing.Point(407, 221);
            this.txt6.Name = "txt6";
            this.txt6.Size = new System.Drawing.Size(100, 22);
            this.txt6.TabIndex = 4;
            this.txt6.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txt4
            // 
            this.txt4.Location = new System.Drawing.Point(407, 157);
            this.txt4.Name = "txt4";
            this.txt4.Size = new System.Drawing.Size(100, 22);
            this.txt4.TabIndex = 17;
            this.txt4.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txt2
            // 
            this.txt2.Location = new System.Drawing.Point(407, 97);
            this.txt2.Name = "txt2";
            this.txt2.Size = new System.Drawing.Size(100, 22);
            this.txt2.TabIndex = 16;
            this.txt2.TabStop = false;
            this.txt2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txt2.TextChanged += new System.EventHandler(this.textBox8_TextChanged);
            // 
            // btn5
            // 
            this.btn5.Location = new System.Drawing.Point(75, 331);
            this.btn5.Name = "btn5";
            this.btn5.Size = new System.Drawing.Size(101, 32);
            this.btn5.TabIndex = 20;
            this.btn5.Text = "&Reset ";
            this.btn5.UseVisualStyleBackColor = true;
            // 
            // btn6
            // 
            this.btn6.Location = new System.Drawing.Point(407, 331);
            this.btn6.Name = "btn6";
            this.btn6.Size = new System.Drawing.Size(75, 23);
            this.btn6.TabIndex = 21;
            this.btn6.Text = "&Exit ";
            this.btn6.UseVisualStyleBackColor = true;
            this.btn6.Click += new System.EventHandler(this.btn6_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(-6, 19);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(585, 31);
            this.label9.TabIndex = 22;
            this.label9.Text = "Enter the value of the Area you want to convert ";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(569, 381);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.btn6);
            this.Controls.Add(this.btn5);
            this.Controls.Add(this.txt8);
            this.Controls.Add(this.txt6);
            this.Controls.Add(this.txt4);
            this.Controls.Add(this.txt2);
            this.Controls.Add(this.txt7);
            this.Controls.Add(this.txt5);
            this.Controls.Add(this.txt3);
            this.Controls.Add(this.txt1);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.btn4);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.btn3);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.btn2);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.btn1);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btn1;
        private System.Windows.Forms.Button btn2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btn3;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btn4;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txt1;
        private System.Windows.Forms.TextBox txt3;
        private System.Windows.Forms.TextBox txt5;
        private System.Windows.Forms.TextBox txt7;
        private System.Windows.Forms.TextBox txt8;
        private System.Windows.Forms.TextBox txt6;
        private System.Windows.Forms.TextBox txt4;
        private System.Windows.Forms.TextBox txt2;
        private System.Windows.Forms.Button btn5;
        private System.Windows.Forms.Button btn6;
        private System.Windows.Forms.Label label9;
    }
}

