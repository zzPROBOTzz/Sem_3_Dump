﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace meet_project
{
    public partial class moneyConvertor : Form
    {
        public moneyConvertor()
        {
            InitializeComponent();
        }

        public class MoneyConv
        {
            // Conversion factors relative to CAD
            private readonly double[] exchangeRates = { 1.00, 0.7353, 0.6757, 0.5952, 61.23, 0.000023 }; // INR and Bitcoin rates
            private readonly string[] currencyCodes = { "CAD", "USD", "EUR", "GBP", "INR", "BTC" };

            public bool IsValidAmount(string amount)
            {
                // Validate input format (0.00 to 999.99)
                string pattern = @"^\d{1,3}(\.\d{1,2})?$";
                return Regex.IsMatch(amount, pattern);
            }

            public double[] ConvertAmount(double baseAmount)
            {
                double[] results = new double[exchangeRates.Length];
                for (int i = 0; i < exchangeRates.Length; i++)
                {
                    results[i] = Math.Round(baseAmount * exchangeRates[i], 2);
                }
                return results;
            }

            public void SaveConversions(string baseCurrency, double baseAmount, double[] conversions)
            {
                string filePath = "MoneyConversions.txt";
                using (StreamWriter writer = new StreamWriter(filePath, true))
                {
                    string dateTime = DateTime.Now.ToString("yyyy/MM/dd (hh:mm:ss tt)");
                    string log = $"{dateTime}, {baseAmount} {baseCurrency} = ";

                    for (int i = 0; i < conversions.Length; i++)
                    {
                        log += $"{conversions[i]} {currencyCodes[i]}";
                        if (i < conversions.Length - 1) log += "; ";
                    }

                    writer.WriteLine(log);
                }
            }

            public string ReadConversions()
            {
                string filePath = "MoneyConversions.txt";
                if (!File.Exists(filePath))
                    return "No conversion records found.";

                using (StreamReader reader = new StreamReader(filePath))
                {
                    return reader.ReadToEnd();
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            MoneyConv converter = new MoneyConv();
            string amountText = textBox1.Text.Trim();

            if (!converter.IsValidAmount(amountText))
            {
                MessageBox.Show("Invalid amount! Enter a value between 0.00 and 999.99.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            double baseAmount = double.Parse(amountText);
            double[] conversions = converter.ConvertAmount(baseAmount);

            // Display results in respective TextBoxes
            textboxCAD.Text = conversions[0].ToString("F2");
            textboxUSA.Text = conversions[1].ToString("F2");
            textboxEUR.Text = conversions[2].ToString("F2");
            textboxGBP.Text = conversions[3].ToString("F2");
            textboxINR.Text = conversions[4].ToString("F2"); // INR
            textboxBTC.Text = conversions[5].ToString("F6");
        }

        private void button2_Click(object sender, EventArgs e)
        {
           
                MoneyConv converter = new MoneyConv();
                string baseCurrency = "CAD"; // Assume CAD as default; modify as needed
                string amountText = textBox1.Text.Trim();

                if (!converter.IsValidAmount(amountText))
                {
                    MessageBox.Show("Invalid amount! Save operation failed.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                double baseAmount = double.Parse(amountText);
                double[] conversions = converter.ConvertAmount(baseAmount);

                try
                {
                    converter.SaveConversions(baseCurrency, baseAmount, conversions);
                    MessageBox.Show("Conversions saved successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error saving conversions: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            

        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
    

}
