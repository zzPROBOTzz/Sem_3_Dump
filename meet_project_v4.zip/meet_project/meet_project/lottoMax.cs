﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace meet_project
{
    public partial class lottoMax : Form
    {
        public lottoMax()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Random random = new Random();
            string randomNumbers = "";

            for (int i = 0; i < 8; i++)
            {
                int randomNumber = random.Next(1, 50);
                randomNumbers += randomNumber.ToString() + Environment.NewLine;
            }

            textBox1.Text = randomNumbers.Trim();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
