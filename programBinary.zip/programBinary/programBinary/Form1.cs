﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace programBinary
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        static string dirPath = @".\Files\"; 
        string path = dirPath + "ProductsB.txt"; 
        FileStream fs = null;

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                fs = new FileStream(path, FileMode.OpenOrCreate, FileAccess.Write); // code that uses the file stream  // to read and write data from the file
                BinaryWriter bw = new BinaryWriter(fs);
                bw.Write(textBox1.Text.Trim());
                bw.Write(textBox2.Text.Trim());
                bw.Close();
                
            }
            catch (FileNotFoundException)
            {
                MessageBox.Show(path + " not found.", "File Not Found");
            }
            catch (DirectoryNotFoundException)
            {
                MessageBox.Show(dirPath + " not found.", "Directory Not Found");
            }
            catch (IOException ex)
            {
                MessageBox.Show(ex.Message, "IOException");
            }
            finally
            {
                if (fs != null) fs.Close();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                fs = new FileStream(path, FileMode.OpenOrCreate, FileAccess.Read);
                // code that uses the file stream  // to read and write data from the file
                BinaryReader br = new BinaryReader(fs);
                string textToPrint = "Fname \t Lname\n";
                string Fname, Lname;

                while(br.PeekChar()!= -1)
                {
                    Fname = br.ReadString();
                    Lname = br.ReadString();
                }
                br.Close();
                MessageBox.Show(textToPrint);
            }
            catch (FileNotFoundException)
            {
                MessageBox.Show(path + " not found.", "File Not Found");
            }
            catch (DirectoryNotFoundException)
            {
                MessageBox.Show(dirPath + " not found.", "Directory Not Found");
            }
            catch (IOException ex)
            {
                MessageBox.Show(ex.Message, "IOException");
            }
            finally
            {
                if (fs != null) fs.Close();
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            if(Directory.Exists(dirPath)==false)Directory.CreateDirectory(dirPath);
        }
    }
}
