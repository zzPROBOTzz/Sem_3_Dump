﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace meet_project
{
   

    public partial class ipv4 : Form
    {
        public ipv4()
        {
            InitializeComponent();
        }
        public class IPv4IPv6Conv
        {
            // Validate IPv4
            public bool IsValidIPv4(string ip)
            {
                string pattern = @"^(\d{1,3}\.){3}\d{1,3}$";
                if (Regex.IsMatch(ip, pattern))
                {
                    string[] parts = ip.Split('.');
                    foreach (string part in parts)
                    {
                        if (int.Parse(part) > 255) return false;
                    }
                    return true;
                }
                return false;
            }

            // Validate IPv6
            public bool IsValidIPv6(string ip)
            {
                string pattern = @"^([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}$";
                return Regex.IsMatch(ip, pattern);
            }
            public void SaveIP(string type, string ip)
            {
                string filePath = "IPRecords.bin";
                using (FileStream fs = new FileStream(filePath, FileMode.Append))
                using (BinaryWriter writer = new BinaryWriter(fs))
                {
                    writer.Write($"{type}: {ip}");
                    writer.Write(DateTime.Now.ToString());
                }
            }
        }


        private void ipv4_Load(object sender, EventArgs e)
        {
            label3.Text = "Today :" + DateTime.Now.ToLongDateString();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            textBox2.Clear();

            MessageBox.Show("Data has been Reset.");
            textBox1.Focus();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string ipv4 = textBox1.Text.Trim(); // IPv4 input
            string ipv6 = textBox2.Text.Trim(); // IPv6 input

            try
            {
                IPv4IPv6Conv converter = new IPv4IPv6Conv();

                if (converter.IsValidIPv4(ipv4))
                {
                    converter.SaveIP("IPv4", ipv4);
                    MessageBox.Show($"IPv4 {ipv4} is valid and saved!");
                }
                else if (converter.IsValidIPv6(ipv6))
                {
                    converter.SaveIP("IPv6", ipv6);
                    MessageBox.Show($"IPv6 {ipv6} is valid and saved!");
                }
                else
                {
                    MessageBox.Show("Invalid IP Address!");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}");
            }
        }
    }
}
