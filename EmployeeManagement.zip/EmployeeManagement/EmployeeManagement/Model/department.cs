﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeManagement.Model
{
    public class department
    {
        private int DepartmentID;
        private string DepartmentName;

        public department()
        {}

        public int DepartmentID1 { get => DepartmentID; set => DepartmentID = value; }
        public string DepartmentName1 { get => DepartmentName; set => DepartmentName = value; }
    }
}
