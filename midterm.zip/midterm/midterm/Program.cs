﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Remoting.Services;
using System.Text;
using System.Threading.Tasks;

namespace midterm
{
    internal class Program
    {
        static void Main(string[] args)
        {
           
           
              while (true)
                    {
                        Console.WriteLine("Teachers Menu");
                        Console.WriteLine("**********************************************");
                        Console.WriteLine("1. Enter Grades");
                        Console.WriteLine("2. Get report");
                        Console.WriteLine("3. Exit Application");
                        Console.WriteLine("**********************************************");

                        Console.WriteLine("Enter your choice: ");
                        string choice = Console.ReadLine();

                        switch(choice)
                        {
                            case "1":
                                enterGrades();
                                break;

                            case "2":
                                getReport();
                                break;
                            case "3":
                                Console.WriteLine("Exit application. Goodbye");
                                return;
                            default:
                                Console.WriteLine("Invalid choice. Please enter a valid option");
                                break;
                        }
              void enterGrades()
                    {
                            Console.WriteLine("Enter student name: ");
                            string studentName = Console.ReadLine();

                           Console.WriteLine("Enter number of grades to enter (greater than zero) : ");
                           int numberOfGrades;
                           while(!int.TryParse(Console.ReadLine(), out numberOfGrades) || numberOfGrades <= 0) 
                                {
                                Console.WriteLine("invalid input. Please enter number greater than zero");
                                }
                           List<int> grades = new List<int>();
                              for( int i = 0; i < numberOfGrades; i++)
                                {
                                Console.WriteLine($"Enter Grade{i + 1}:");
                                int grade;
                                while(int.TryParse(Console.ReadLine(),out grade) || grade < 0 || grade > 100)
                                {
                                    Console.WriteLine("invalid input. Please enter number between 0 to 100");
                                }
                                grades.Add(grade);
                                }
                                Console.WriteLine($"Grades for {studentName} have been entered successfully");
                               }
              void getReport()
                    {
                    List<int> grades = new List<int> { 85, 90, 75};

                    int total = 0;
                    foreach( int grade in grades )
                    {
                        total += grade;
                    }
                    double average = (double)total / grades.Count;
                    char letterGrade;
                    if(average >= 90)
                    {
                        letterGrade = 'A';
                    }
                    else if(average >= 80)
                    {
                        letterGrade = 'B';
                    }
                    else if( average >= 70)
                    {
                        letterGrade = 'C';
                    }
                    else if(average >= 60)
                    {
                        letterGrade = 'D';
                    }
                    else{
                        letterGrade = 'F';
                    }

                    Console.WriteLine($"Student Name: {grades[0]}");
                    Console.WriteLine($"Average of grade: {average}");
                    Console.WriteLine($"Letter Final Grade: {letterGrade}");
                }
              }
            }

        }
    }

