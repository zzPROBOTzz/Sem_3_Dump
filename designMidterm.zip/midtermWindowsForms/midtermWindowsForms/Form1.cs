﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace midtermWindowsForms
{
    public partial class frmLengthConvertor : Form
    {
        public class LengthConvert
        {
            private double meters;
            private double kilometers;

            // Constructor for Meters
            public LengthConvert(double meters)
            {
                Meters = meters;
            }

            // Constructor for Kilometers
            public LengthConvert(double kilometers, bool isKilometers)
            {
                Kilometers = kilometers;
            }

            public double Meters
            {
                get { return meters; }
                set { meters = value; }
            }

            public double Kilometers
            {
                get { return kilometers; }
                set { kilometers = value; }
            }

            public double MtoYd()
            {
                return Meters * 1.09361;
            }

            public double KmToMile()
            {
                return Kilometers * 0.621371;
            }
        }
        public frmLengthConvertor()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {

        }
    }
}
